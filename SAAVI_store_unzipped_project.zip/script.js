/* SAAVI STORE — EASY EDIT AREA
   Add/change products below. For each product you can edit:
   name, category, price, description, image.
*/
const products = [
 {id:1,name:'Classic Satin Scrunchie',category:'Scrunchies',price:49,description:'Soft premium satin with a luxe finish.',image:'assets/saavi-logo.png'},
 {id:2,name:'Tulip Scrunchie',category:'Scrunchies',price:59,description:'A pretty floral-inspired scrunchie.',image:'assets/saavi-logo.png'},
 {id:3,name:'Butterfly Clip',category:'Accessories',price:39,description:'A delicate little finishing touch.',image:'assets/saavi-logo.png'},
 {id:4,name:'Bestie Gift Combo',category:'Gift Sets',price:149,description:'A sweet ready-to-gift SAAVI set.',image:'assets/saavi-logo.png'},
 {id:5,name:'Pastel Scrunchie Set',category:'Gift Sets',price:179,description:'A curated set of soft luxury shades.',image:'assets/saavi-logo.png'},
 {id:6,name:'Custom Colour Scrunchie',category:'Custom',price:69,description:'Choose your colour for a personalised piece.',image:'assets/saavi-logo.png'}
];
let cart = JSON.parse(localStorage.getItem('saaviCart')||'[]');
const $=s=>document.querySelector(s);
function money(n){return '₹'+n.toLocaleString('en-IN')}
function save(){localStorage.setItem('saaviCart',JSON.stringify(cart));renderCart();}
function renderProducts(filter='All'){
 const list=filter==='All'?products:products.filter(p=>p.category===filter);
 $('#products').innerHTML=list.map(p=>`<article class="product"><div class="product-img"><img src="${p.image}" alt="${p.name}"></div><div class="product-info"><h3>${p.name}</h3><p>${p.description}</p><div class="price-row"><strong>${money(p.price)}</strong><button class="add" onclick="add(${p.id})">Add +</button></div></div></article>`).join('');
 $('#productCount').textContent=`${list.length} pieces`;
}
function renderFilters(){
 const cats=['All',...new Set(products.map(p=>p.category))];
 $('#filters').innerHTML=cats.map((c,i)=>`<button class="filter ${i===0?'active':''}" data-cat="${c}">${c}</button>`).join('');
 document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderProducts(b.dataset.cat)});
}
function add(id){const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id,qty:1});save();openCart()}
function change(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);save()}
function renderCart(){
 $('#cartCount').textContent=cart.reduce((a,x)=>a+x.qty,0);
 $('#cartItems').innerHTML=cart.length?cart.map(x=>{const p=products.find(p=>p.id===x.id);return `<div class="cart-line"><img class="cart-thumb" src="${p.image}" alt=""><div><strong>${p.name}</strong><div class="qty"><button onclick="change(${p.id},-1)">−</button>${x.qty}<button onclick="change(${p.id},1)">+</button></div></div><strong>${money(p.price*x.qty)}</strong></div>`}).join(''):'<p style="color:#7e7066">Your bag is waiting for something pretty. 🎀</p>';
 $('#subtotal').textContent=money(cart.reduce((a,x)=>a+products.find(p=>p.id===x.id).price*x.qty,0));
}
function openCart(){$('#cartDrawer').classList.add('open');$('#backdrop').classList.add('show')}
function closeCart(){$('#cartDrawer').classList.remove('open');$('#backdrop').classList.remove('show')}
$('#cartOpen').onclick=openCart;$('#cartClose').onclick=closeCart;$('#backdrop').onclick=closeCart;
$('#checkoutBtn').onclick=()=>{if(!cart.length)return alert('Please add something to your bag first.');closeCart();$('#checkoutModal').classList.add('show')};
document.querySelector('[data-close]').onclick=()=>$('#checkoutModal').classList.remove('show');
$('#customBtn').onclick=()=>{document.querySelector('#checkoutModal').classList.add('show');document.querySelector('#checkoutForm').scrollIntoView({behavior:'smooth'})};
$('#checkoutForm').onsubmit=e=>{e.preventDefault();const data=new FormData(e.target);const orderId='SAAVI-'+Math.floor(10000+Math.random()*90000);localStorage.setItem('lastSaaviOrder',JSON.stringify({orderId,customer:Object.fromEntries(data),cart}));cart=[];save();$('#checkoutModal').classList.remove('show');$('#orderNumber').textContent='Order '+orderId;$('#success').classList.add('show');burst();e.target.reset();};
function burst(){const c=$('#confetti');c.innerHTML='';for(let i=0;i<75;i++){const el=document.createElement('i');el.className='piece';el.style.setProperty('--x',`${Math.round(Math.random()*900-450)}px`);el.style.setProperty('--y',`${Math.round(Math.random()*700-350)}px`);el.style.transform=`translate(-50%,-50%) rotate(${Math.random()*360}deg)`;el.style.animationDelay=`${Math.random()*180}ms`;c.appendChild(el)}}
$('#continueBtn').onclick=()=>$('#success').classList.remove('show');
renderFilters();renderProducts();renderCart();
