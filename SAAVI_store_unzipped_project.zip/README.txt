SAAVI STORE — QUICK SETUP

This is a polished mobile-first storefront prototype for SAAVI.

1. Open index.html in a browser to preview it.
2. Edit products in script.js under the EASY EDIT AREA.
3. Replace each product's image path with your own product image.
4. The logo is already included in assets/saavi-logo.png.
5. The cart and checkout confirmation work in the browser. The HURRAY + confetti animation appears AFTER checkout.

IMPORTANT FOR A REAL LIVE STORE:
This version is the storefront/prototype. Before publishing, connect:
- a real payment gateway (for example Razorpay/Stripe depending on your setup),
- an order database/admin dashboard,
- email/WhatsApp order notifications,
- shipping/delivery settings.
Those require your business account details and should be configured securely; do not put payment secret keys in this frontend code.
